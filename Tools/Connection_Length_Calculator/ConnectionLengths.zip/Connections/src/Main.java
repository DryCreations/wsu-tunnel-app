	import java.io.BufferedReader;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.text.DecimalFormat;
	import java.util.ArrayList;



public class Main {


		public static void main(String[] args) {
			String nodePath = "E:\\Documents\\nodes.csv\\";
			String connectionsPath = "E:\\Documents\\connections.csv\\";
			String outputPath ="E:\\Documents\\lengths.csv\\";
			
			ArrayList<String[]> nodes = readNodeCSV(nodePath);
			ArrayList<TunnelNode> tunnelNodes = new ArrayList<>();
			ArrayList<String[]> connections = getConnection(connectionsPath);
			
			
			//create node objects
			for(String[] node : nodes )
			{
				tunnelNodes.add(new TunnelNode(Integer.parseInt(node[0]),Double.parseDouble(node[1]),Double.parseDouble(node[2])));
			}
			
			try {
			calculateLengths(outputPath, tunnelNodes, connections);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
			

		
		
		//Read file to get nodes
		public static ArrayList<String[]> readNodeCSV(String nodePath)
		{
			String csvFile = nodePath;
			BufferedReader br = null;
			String line = "";
			String csvSplitBy= ",";
			ArrayList<String[]> nodes = new ArrayList<>();
			try {
				br = new BufferedReader(new FileReader(csvFile));
				while ((line = br.readLine()) != null) {
						nodes.add(line.split(csvSplitBy));
					
				}
			}
			catch ( FileNotFoundException e) {
				e.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();	
			}
			finally {
				if (br != null) {
					try {
						br.close();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
			return nodes;
		}
		
		//Read file to get Connections
		public static ArrayList<String[]> getConnection(String connectionPath)
		{
			String csvFile = "E:\\Documents\\connections.csv\\";
			BufferedReader br = null;
			String line = "";
			String csvSplitBy= ",";
			ArrayList<String[]> connections = new ArrayList<>();
			try {
				br = new BufferedReader(new FileReader(csvFile));
				while ((line = br.readLine()) != null) {
						connections.add(line.split(csvSplitBy));
					
				}
			}
			catch ( FileNotFoundException e) {
				e.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();	
			}
			finally {
				if (br != null) {
					try {
						br.close();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
			return connections;
	
		}
		
		//Calculate distance
		public static void calculateLengths(String outputPath, ArrayList<TunnelNode> tunnelNodes, ArrayList<String[]> connections) throws FileNotFoundException
		{
			double lat1;
			double lon1;
			double lat2;
			double lon2;
			double R = 6378;
			int count=1;
			double pi = Math.atan2(1, 1)*4;
			
			PrintWriter writer = new PrintWriter(outputPath);
			
			for (String[] connection : connections) {
				lat1 = Math.toRadians(tunnelNodes.get(Integer.parseInt(connection[1])-1).getLat());
				lon1 = Math.toRadians(tunnelNodes.get(Integer.parseInt(connection[1])-1).getLon());
				lat2 = Math.toRadians(tunnelNodes.get(Integer.parseInt(connection[2])-1).getLat());
				lon2 = Math.toRadians(tunnelNodes.get(Integer.parseInt(connection[2])-1).getLon());
				
				double dlon = lon2 - lon1;
			    double dlat = lat2 - lat1;	
		    	double a = (Math.pow(Math.sin(dlat/2),2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow((Math.sin(dlon/2)),2));
				double c = 2 * Math.atan2( Math.sqrt(a), Math.sqrt(1-a));
				double d = R * c;
				
				
				DecimalFormat df = new DecimalFormat("#.####");
				writer.println(count++ +", " + connection[1]+", " + connection[2]+ ", " + df.format(d*1000));
			}
			writer.close();
		}
	}




